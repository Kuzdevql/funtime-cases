<?php

namespace ResourceCase\task;

use pocketmine\scheduler\Task;
use pocketmine\entity\Villager;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\math\Vector3;
use ResourceCase\Main;

class VillagerDeathTask extends Task {

    private Main $plugin;
    private Villager $villager;
    private int $ticksToLive;
    private int $count = 0;

    public function __construct(Main $plugin, Villager $villager, int $ticksToLive = 8) {
        $this->plugin = $plugin;
        $this->villager = $villager;
        $this->ticksToLive = $ticksToLive;
    }

    public function onRun($currentTick) {
        if ($this->villager->isClosed()) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $level = $this->villager->getLevel();
        $pos = $this->villager->asVector3();

        if ($this->count === 0) {
            $level->addSound(new AnvilFallSound($pos));
        }

        if ($this->count < $this->ticksToLive) {

            for ($i = 0; $i < 12; $i++) {
                $offsetX = mt_rand(-10, 10) / 10;
                $offsetY = mt_rand(0, 10) / 10;
                $offsetZ = mt_rand(-10, 10) / 10;

                if (mt_rand(0, 1) === 0) {
                    $level->addParticle(new FlameParticle($pos->add($offsetX, $offsetY, $offsetZ)));
                } else {
                    $level->addParticle(new SmokeParticle($pos->add($offsetX, $offsetY, $offsetZ)));
                }
            }

            $level->addParticle(new DustParticle($pos->add(0, 1, 0), 1.0, 0, 0, 1.0));

            if ($this->count === $this->ticksToLive - 2) {
                for ($i = 0; $i < 20; $i++) {
                    $offsetX = mt_rand(-15, 15) / 10;
                    $offsetY = mt_rand(0, 10) / 10;
                    $offsetZ = mt_rand(-15, 15) / 10;
                    $level->addParticle(new FlameParticle($pos->add($offsetX, $offsetY, $offsetZ)));
                }
                $level->addSound(new AnvilFallSound($pos));
            }
        } else {
            $this->villager->close();
            unset($this->plugin->spawnedVillagers[$this->villager->getId()]);
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
        }

        $this->count++;
    }
}
