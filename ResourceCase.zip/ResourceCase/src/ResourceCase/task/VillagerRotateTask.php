<?php

namespace ResourceCase\task;

use pocketmine\scheduler\Task;
use pocketmine\entity\Villager;
use ResourceCase\Main;

class VillagerRotateTask extends Task {

    private Main $plugin;
    private Villager $villager;
    private float $yaw = 0.0;

    public function __construct(Main $plugin, Villager $villager){
        $this->plugin = $plugin;
        $this->villager = $villager;
    }

    public function onRun($currentTick) {
        if ($this->villager->isClosed()) {
            $this->getHandler()->cancel();
            return;
        }

        $this->yaw += 5;
        if ($this->yaw >= 360) {
            $this->yaw = 0;
        }

        $this->villager->setRotation($this->yaw, $this->villager->getPitch());

        if (method_exists($this->villager, "sendMotionPacket")) {
            $this->villager->sendMotionPacket();
        }
    }
}
