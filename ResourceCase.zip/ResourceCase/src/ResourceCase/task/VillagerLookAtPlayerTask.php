<?php

namespace ResourceCase\task;

use pocketmine\scheduler\PluginTask;
use pocketmine\entity\Villager;
use pocketmine\Player;
use pocketmine\math\Vector3;
use ResourceCase\Main;

class VillagerLookAtPlayerTask extends PluginTask {

    private Villager $villager;
    private Player $player;

    public function __construct(Main $plugin, Villager $villager, Player $player) {
        parent::__construct($plugin);
        $this->villager = $villager;
        $this->player = $player;
    }

    public function onRun($currentTick) {
        if ($this->villager->isClosed() || $this->player->isClosed()) {
            $this->getHandler()->cancel();
            return;
        }

        $villagerPos = $this->villager->asVector3();
        $playerPos = $this->player->asVector3()->add(0, $this->player->getEyeHeight(), 0);
        $diff = $playerPos->subtract($villagerPos);

        $yaw = rad2deg(-atan2($diff->x, $diff->z));
        if ($yaw < 0) {
            $yaw += 360;
        }

        $horizontalDistance = sqrt($diff->x ** 2 + $diff->z ** 2);
        $pitch = rad2deg(-atan2($diff->y, $horizontalDistance));

        $this->villager->setRotation($yaw, $pitch);
    }
}
