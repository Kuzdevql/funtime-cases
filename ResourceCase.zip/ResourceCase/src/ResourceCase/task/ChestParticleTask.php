<?php

namespace ResourceCase\task;

use pocketmine\scheduler\Task;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\level\Level;

class ChestParticleTask extends Task {

    private Level $level;
    private Vector3 $center;
    private Player $player;
    private int $tick = 0;

    public function __construct(Level $level, Vector3 $center, Player $player) {
        $this->level = $level;
        $this->center = $center;
        $this->player = $player;
    }

    public function onRun($currentTick) {
        if ($this->tick >= 60) {
            // телепорт к центру
            $this->player->teleport($this->center);
            $this->player->sendTitle("§cВыберите жителя");

            $plugin = $this->player->getServer()->getPluginManager()->getPlugin("ResourceCase");
            if ($plugin !== null) {
                $plugin->spawnVillagersAround($this->player, $this->center);
            }

            $this->getHandler()->cancel();
            return;
        }

        $radius = 1.5;
        for ($angle = 0; $angle < 360; $angle += 30) {
            $x = $this->center->x + $radius * cos(deg2rad($angle));
            $z = $this->center->z + $radius * sin(deg2rad($angle));
            $y = $this->center->y + 0.5;

            $pos = new Vector3($x, $y, $z);
            $this->level->addParticle(new CriticalParticle($pos));
        }

        $this->tick++;
    }
}
