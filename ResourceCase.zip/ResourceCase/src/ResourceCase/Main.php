<?php

namespace ResourceCase;

use ResourceCase\task\ChestParticleTask;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\Entity;
use pocketmine\entity\Villager;
use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

use ResourceCase\task\VillagerRotateTask;
use ResourceCase\task\VillagerDeathTask;

class Main extends PluginBase implements Listener {

    private int $chestBlockId = 54;

    /** @var Villager[] */
    public array $spawnedVillagers = [];

    /** @var bool[] */
    private array $frozenPlayers = [];

    /** @var array<string, int> */
    private array $lastOpenTime = [];

    /** @var array<int, \pocketmine\level\Position> */
    private array $kuzChests = [];


    /** @var array<string, Item[]> */
    private array $kits = [];

    public function onEnable(): void {
        Entity::registerEntity(Villager::class, true);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->kits = [];

        $pvpKit = [
            Item::get(Item::DIAMOND_SWORD)->setCustomName("§bPvP Sword")->setLore(["§7Острый и смертоносный"]),
            Item::get(Item::DIAMOND_CHESTPLATE),
            Item::get(Item::DIAMOND_LEGGINGS),
            Item::get(Item::DIAMOND_BOOTS),
            Item::get(Item::GOLDEN_APPLE, 0, 5),
        ];

        $grieferKit = [
            Item::get(Item::FLINT_AND_STEEL),
            Item::get(Item::TNT, 0, 16),
            Item::get(Item::OBSIDIAN, 0, 32),
            Item::get(Item::DIAMOND_PICKAXE),
        ];

        $builderKit = [
            Item::get(Item::WOODEN_AXE),
            Item::get(Item::WOODEN_PLANKS, 0, 64),
            Item::get(Item::GLASS, 0, 32),
            Item::get(Item::LADDER, 0, 32),
        ];

        $survivalKit = [
            Item::get(Item::BREAD, 0, 16),
            Item::get(Item::IRON_SWORD),
            Item::get(Item::IRON_PICKAXE),
            Item::get(Item::TORCH, 0, 32),
        ];

        $this->kits["Набор пвпшера"] = $pvpKit;
        $this->kits["Набор грифера"] = $grieferKit;
        $this->kits["Набор строителя"] = $builderKit;
        $this->kits["Классический набор анархиста"] = $survivalKit;
    }

    public function onMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        if (isset($this->frozenPlayers[$player->getName()])) {
            $from = $event->getFrom();
            $to = $event->getTo();
            if ($from->x !== $to->x || $from->z !== $to->z) {
                $event->setTo($from);
            }
        }
    }

    public function spawnVillagersAround(Player $player, Vector3 $center): void {
    $pos = $center->asPosition();
    $radius = 2;
    $level = $player->getLevel();
    $angles = [0, 90, 180, 270];

    $this->frozenPlayers[$player->getName()] = true;

    foreach ($angles as $angle) {
        $x = $pos->x + cos(deg2rad($angle)) * $radius;
        $z = $pos->z + sin(deg2rad($angle)) * $radius;
        $spawnPos = new Position($x, $pos->y, $z, $level);

        $nbt = Entity::createBaseNBT($spawnPos, new Vector3(0, 0, 0), 0, 0);
        $villager = new Villager($level, $nbt);
        $villager->setNameTagVisible(true);
        $villager->setNameTagAlwaysVisible(true);
        $villager->setNameTag("§eЖми сюда\n§7Полный рандом");

        if (method_exists($villager, "setImmobile")) {
            $villager->setImmobile(true);
        }

        $villager->spawnToAll();
        $this->spawnedVillagers[$villager->getId()] = $villager;
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new VillagerRotateTask($this, $villager), 1);
    }
}


    public function onCommand(CommandSender $sender, Command $command, $label, array $args): bool {
    if (strtolower($command->getName()) === "kuz") {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Команду может использовать только игрок.");
            return true;
        }

        $level = $sender->getLevel();
        $pos = $sender->floor()->subtract(0, 1, 0);
        $level->setBlock($pos, Item::get($this->chestBlockId)->getBlock());

        $this->kuzChests[] = $pos->asVector3();

        $sender->sendMessage("§a✔ §fВы успешно §eзаспавнили §fсундук с §bресурсами!");
        return true;
    }
    return false;
}

    public function onInteract(PlayerInteractEvent $event): void {
    $player = $event->getPlayer();
    $block = $event->getBlock();

    if ($block->getId() === $this->chestBlockId) {
        $pos = $block->asVector3();

        $found = false;
        foreach ($this->kuzChests as $chestPos) {
            if ($pos->equals($chestPos)) {
                $found = true;
                break;
            }
        }

        if (!$found) {
            return;
        }

        $event->setCancelled();

        $player->getLevel()->sendBlocks([$player], [$block]);

        $name = $player->getName();
        $currentTime = time();

        if (isset($this->lastOpenTime[$name])) {
            $elapsed = $currentTime - $this->lastOpenTime[$name];
            if ($elapsed < 900) {
                $remaining = 900 - $elapsed;
                $minutes = floor($remaining / 60);
                $seconds = $remaining % 60;
                $player->sendMessage("§c✘ §fВы сможете открыть кейс через §e{$minutes}м §fи §e{$seconds}с§f.");
                return;
            }
        }

        $this->lastOpenTime[$name] = $currentTime;

        $center = $block->add(0.5, 1, 0.5);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new ChestParticleTask($player->getLevel(), $center, $player), 1);
    }
}

    public function onDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();

        if (isset($this->spawnedVillagers[$entity->getId()])) {
            $event->setCancelled();

            if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
                if ($damager instanceof Player) {
                    foreach ($this->spawnedVillagers as $id => $villager) {
                        $this->getServer()->getScheduler()->scheduleRepeatingTask(new VillagerDeathTask($this, $villager), 1);
                    }

                    $kitName = array_rand($this->kits);
                    $items = $this->kits[$kitName];

                    foreach ($items as $item) {
                        $damager->getInventory()->addItem($item);
                    }

                    $damager->sendMessage("§a✓ §fВы §eполучаете: §d{$kitName}");

                    unset($this->frozenPlayers[$damager->getName()]);
                }
            }
        }
    }
}
